import logo from './logo.svg';
import './App.css';
import Color from './components/drop';

function App() {
  return (
    <div className="App">
     <Color/>
    </div>
  );
}

export default App
