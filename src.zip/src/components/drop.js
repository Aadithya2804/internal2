import { React, useState } from 'react';
import Select from 'react-select';

const Color = () => {

    const colors = [{
        id: 1,
        label: "yellow",
    },
    {
        id: 2,
        label: "red",
    },
    {
        id: 3,
        label: "black",
    },
    {
        id: 4,
        label: "orangered",
    },
    {
        id: 5,
        label: "green",
    },
    {
        id: 6,
        label: "purple",
    },
    {
        id: 7,
        label: "brown",
    }
    ]

    const [color, setColor] = useState("");

    const click = (event) => {
        setColor(event.label);
    }
    return (
        <div>
            <style>
                {
                    `body{
                        background-color:` + color + ';'
                }
            </style>
            <Select options={colors} onChange={click}></Select>
        </div>

    );
}
export default Color;